#include "mqtt.h"
#include "osapi.h"

MQTT_Client mqttClient;

/******************************************************************************
 *
 *******************************************************************************/
void ICACHE_FLASH_ATTR
mqttConnectedCb(uint32_t *args)
{
	MQTT_Client* client = (MQTT_Client*)args;
	os_printf("MQTT: Connected\r\n");
	//��������
	MQTT_Subscribe(client, sub_topic_id[0], 0);
	MQTT_Subscribe(client, sub_topic_id[1], 0);

	MQTT_Publish(client, device_uuid, "online", 6, 0, 0);


}

/******************************************************************************
 *
 *******************************************************************************/
void ICACHE_FLASH_ATTR
mqttDisconnectedCb(uint32_t *args)
{
	MQTT_Client* client = (MQTT_Client*)args;
	os_printf("MQTT: Disconnected\r\n");
}

/******************************************************************************
 *
 *******************************************************************************/
void ICACHE_FLASH_ATTR
mqttPublishedCb(uint32_t *args)
{
	//MQTT_Client* client = (MQTT_Client*)args;
	os_printf("MQTT: Published\r\n");
}


/******************************************************************************
 *
 *******************************************************************************/
void ICACHE_FLASH_ATTR
mqtt_connect(void)
{
	MQTT_Connect(&mqttClient);
}

/******************************************************************************
 *
 *******************************************************************************/
void ICACHE_FLASH_ATTR
mqtt_disconnect(void)
{
	MQTT_Disconnect(&mqttClient);
}

/******************************************************************************
 *
 *******************************************************************************/
void ICACHE_FLASH_ATTR
mqtt_config(MqttDataCallback dataCb)
{
	//MQTT_InitConnection(&mqttClient, sysCfg.mqtt_host, sysCfg.mqtt_port, sysCfg.security);
	//��ʼ��MQTT��������
	MQTT_InitConnection(&mqttClient, MQTT_HOST, MQTT_PORT, 0);

	//MQTT_InitClient(&mqttClient, sysCfg.device_id, sysCfg.mqtt_user, sysCfg.mqtt_pass, sysCfg.mqtt_keepalive, 1);
	//��ʼ��MQTT�ͻ�������
	MQTT_InitClient(&mqttClient, device_uuid, MQTT_USER, MQTT_PASS, 60, 1);

	MQTT_InitLWT(&mqttClient, device_uuid, "offline", 0, 0); //����
	MQTT_OnConnected(&mqttClient, mqttConnectedCb);			 //����������ɻص�����
	MQTT_OnDisconnected(&mqttClient, mqttDisconnectedCb);	 //���öϿ����ӻص�����
	MQTT_OnPublished(&mqttClient, mqttPublishedCb);			 //���÷����ص�����
	MQTT_OnData(&mqttClient, dataCb);						 //���ö��Ļص�����
}

void ICACHE_FLASH_ATTR mqtt_Publish(const char* topic, const char* data, int data_length, int qos, int retain)
{
	MQTT_Publish(&mqttClient, topic, data, data_length, qos, retain);
}
