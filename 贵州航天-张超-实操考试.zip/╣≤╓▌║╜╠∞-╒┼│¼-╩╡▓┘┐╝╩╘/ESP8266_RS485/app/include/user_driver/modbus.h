/*
 * modbus.h
 *
 *  Created on: 2018��3��14��
 *      Author: Qian
 */

#include "c_types.h"

#ifndef APP_INCLUDE_USER_DRIVER_MODBUS_H_
#define APP_INCLUDE_USER_DRIVER_MODBUS_H_

#define H_RX_BUF_SIZE		32
#define H_TX_BUF_SIZE      	64

typedef struct
{
	uint8_t RxBuf[H_RX_BUF_SIZE];
	uint8_t RxCount;
	uint8_t RxStatus;

	uint8_t TxBuf[H_TX_BUF_SIZE];
	uint8_t TxCount;

}MODH_T;


void MODH_init(void);

#endif /* APP_INCLUDE_USER_DRIVER_MODBUS_H_ */
