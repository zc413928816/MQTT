/*
 * LED.h
 *
 *  Created on: 2018��1��11��
 *      Author: Qian
 */

#ifndef APP_INCLUDE_USER_DRIVER_LED_H_
#define APP_INCLUDE_USER_DRIVER_LED_H_

#include "eagle_soc.h"
#include "c_types.h"
#include "gpio.h"


#define LED_MUX1  PERIPHS_IO_MUX_GPIO2_U
#define LED_FUNC1 FUNC_GPIO2
#define LED_NUM1  2

#define LED_MUX			PERIPHS_IO_MUX_MTDI_U
#define LED_FUNC		FUNC_GPIO12
#define LED_NUM			12


#define LED_ON1			GPIO_OUTPUT_SET(LED_NUM, 1)
#define LED_OFF1	    GPIO_OUTPUT_SET(LED_NUM, 0)

#define LED_ON			GPIO_OUTPUT_SET(LED_NUM, 1)
#define LED_OFF			GPIO_OUTPUT_SET(LED_NUM, 0)


void LED_init(void);

#endif /* APP_INCLUDE_USER_DRIVER_LED_H_ */
