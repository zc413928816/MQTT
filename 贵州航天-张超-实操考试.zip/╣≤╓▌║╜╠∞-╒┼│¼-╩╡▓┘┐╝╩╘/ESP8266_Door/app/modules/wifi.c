/*
 * wifi.c
 *
 *  Created on: Dec 30, 2014
 *      Author: Minh
 */
#include "wifi.h"
#include "user_interface.h"
#include "osapi.h"
#include "espconn.h"
#include "os_type.h"
#include "mem.h"
#include "mqtt_msg.h"
#include "debug.h"
#include "user_config.h"
#include "config.h"
#include "smartconfig.h"

struct station_config s_staconf;

static ETSTimer WiFiLinker;
WifiCallback wifiCb = NULL;
static uint8_t wifiStatus = STATION_IDLE, lastWifiStatus = STATION_IDLE;
static void ICACHE_FLASH_ATTR wifi_check_ip(void *arg)
{
	struct ip_info ipConfig;

	// 取消定时器
	os_timer_disarm(&WiFiLinker);

	// 查询 Wi-Fi Station 接⼝
	wifi_get_ip_info(STATION_IF, &ipConfig);

	// 查询 ESP8266 Wi-Fi Station 接⼝连接 AP 的状态
	wifiStatus = wifi_station_get_connect_status();
	if (wifiStatus == STATION_GOT_IP && ipConfig.ip.addr != 0)
	{
		// 已经获取到IP 设置定时器，2000ms后再次查询
		os_timer_setfn(&WiFiLinker, (os_timer_func_t *)wifi_check_ip, NULL);
		os_timer_arm(&WiFiLinker, 2000, 0);
	}
	else
	{
		if(wifi_station_get_connect_status() == STATION_WRONG_PASSWORD)
		{
			// passwd 错误
			INFO("STATION_WRONG_PASSWORD\r\n");
			wifi_station_connect();
		}
		else if(wifi_station_get_connect_status() == STATION_NO_AP_FOUND)
		{
			// 没有发现 AP
			INFO("STATION_NO_AP_FOUND\r\n");
			wifi_station_connect();
		}
		else if(wifi_station_get_connect_status() == STATION_CONNECT_FAIL)
		{
			// 连接失败
			INFO("STATION_CONNECT_FAIL\r\n");
			wifi_station_connect();
		}
		else
		{
			// station 空闲
			INFO("STATION_IDLE\r\n");
		}

		// 设置定时器 500ms后再次查询
		os_timer_setfn(&WiFiLinker, (os_timer_func_t *)wifi_check_ip, NULL);
		os_timer_arm(&WiFiLinker, 500, 0);
	}
	if(wifiStatus != lastWifiStatus){ //如果wifi 状态改变，调用状态改变回调函数
		lastWifiStatus = wifiStatus;
		if(wifiCb)
			wifiCb(wifiStatus);
	}
}

void ICACHE_FLASH_ATTR WIFI_Connect(uint8_t* ssid, uint8_t* pass, WifiCallback cb)
{
	struct station_config stationConf;

	INFO("WIFI_INIT\r\n");

	// 申请stationConf空间
	os_memset(&stationConf, 0, sizeof(struct station_config));

	// 将ssid和passwd 填入stationConf
	os_sprintf(stationConf.ssid, "%s", ssid);
	os_sprintf(stationConf.password, "%s", pass);

	// 设置 Wi-Fi Station 接⼝的配置参数
	wifi_station_set_config_current(&stationConf);

	// 设置定时器 1000ms后查询ip
	os_timer_disarm(&WiFiLinker);
	os_timer_setfn(&WiFiLinker, (os_timer_func_t *)wifi_check_ip, NULL);
	os_timer_arm(&WiFiLinker, 1000, 0);

	//wifi_station_set_auto_connect(TRUE); 连接wifi
	wifi_station_connect();
}

void ICACHE_FLASH_ATTR
connect_wifi(void)
{
	// 设置wifi连接配置，不保存到存储器，并以此配置连接WIFI
	wifi_station_set_config_current(&s_staconf);
}

void ICACHE_FLASH_ATTR
smartconfig_done(sc_status status, void *pdata)
{
    switch(status) {
        case SC_STATUS_WAIT:
            os_printf("SC_STATUS_WAIT\n");
            break;
        case SC_STATUS_FIND_CHANNEL:
            os_printf("SC_STATUS_FIND_CHANNEL\n");
            break;
        case SC_STATUS_GETTING_SSID_PSWD:
            os_printf("SC_STATUS_GETTING_SSID_PSWD\n");
			sc_type *type = pdata;
            if (*type == SC_TYPE_ESPTOUCH) {
                os_printf("SC_TYPE:SC_TYPE_ESPTOUCH\n");
            } else {
                os_printf("SC_TYPE:SC_TYPE_AIRKISS\n");
            }
            break;
        case SC_STATUS_LINK:  //完成连接
            os_printf("SC_STATUS_LINK\n");
            struct station_config *sta_conf = pdata;

            //设置wifi连接配置，保存到存储器
	        wifi_station_set_config(sta_conf);
	        wifi_station_disconnect(); // 断开当前连接
	        wifi_station_connect();    // 连接 wifi
            break;
        case SC_STATUS_LINK_OVER: // WIFI 连接完成
            os_printf("SC_STATUS_LINK_OVER\n");
            if (pdata != NULL) {
				//SC_TYPE_ESPTOUCH
                uint8 phone_ip[4] = {0};

                os_memcpy(phone_ip, (uint8*)pdata, 4);
                os_printf("Phone ip: %d.%d.%d.%d\n",phone_ip[0],phone_ip[1],phone_ip[2],phone_ip[3]);
            } else {
            	//SC_TYPE_AIRKISS - support airkiss v2.0
				//airkiss_start_discover();
            }
            smartconfig_stop();
            break;
    }
}

void smartconfig(WifiCallback cb)
{
	// 查询是否有保存的WIFI设置
    wifi_station_get_config_default(&s_staconf);

    if (os_strlen(s_staconf.ssid) != 0)
    {
      // 有保存设置，直接用保存的设置进行连接
      os_printf("connect_wifi\n");
      // 系统初始化完成后调用connect_wifi函数连接wifi
      system_init_done_cb(connect_wifi);
    }
    else
    {
      // 没有保存WIFI设置，进入SmartConfig 模式
      os_printf("smartcfg\n");
      smartconfig_set_type(SC_TYPE_ESPTOUCH);
      // 开始Smartconfig 并设置完成后的回调函数smartconfig_done
      smartconfig_start(smartconfig_done);
    }

    // 设置定时器 2000ms后查询 IP
	os_timer_disarm(&WiFiLinker);
	os_timer_setfn(&WiFiLinker, (os_timer_func_t *)wifi_check_ip, NULL);
	os_timer_arm(&WiFiLinker, 3000, 0);
}


void ICACHE_FLASH_ATTR wifi_Connect(WifiCallback cb)
{
	// 保存回调函数指针
	wifiCb = cb;

#if( WIFI_SMARTCONFIG )
	// SmartConfig 方式连接WIFI
	smartconfig(cb);
#else
	// 直接连接WIFI
	WIFI_Connect(SSID, PASSWD, cb);
#endif
}

void enter_wifiConfig(void)
{
	wifi_station_disconnect();
	smartconfig_set_type(SC_TYPE_ESPTOUCH);
	smartconfig_start(smartconfig_done);
}
