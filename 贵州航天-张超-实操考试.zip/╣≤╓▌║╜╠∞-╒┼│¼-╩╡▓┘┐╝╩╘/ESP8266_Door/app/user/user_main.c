/* main.c -- MQTT client example
*
* Copyright (c) 2014-2015, Tuan PM <tuanpm at live dot com>
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* * Redistributions of source code must retain the above copyright notice,
* this list of conditions and the following disclaimer.
* * Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in the
* documentation and/or other materials provided with the distribution.
* * Neither the name of Redis nor the names of its contributors may be used
* to endorse or promote products derived from this software without
* specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
* SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
* INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
* CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
* ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
* POSSIBILITY OF SUCH DAMAGE.
*/
#include "ets_sys.h"
#include "driver/uart.h"
#include "driver/key.h"
#include "osapi.h"
#include "user_interface.h"
#include "mem.h"
#include "wifi.h"
#include "user_mqtt.h"
#include "door.h"


os_timer_t auto_closedoor_timer;

static struct keys_param key_param;
static struct single_key_param *single_key[2];

#define keys_Pin_NUM         0
#define keys_Pin_FUNC        FUNC_GPIO0
#define keys_Pin_MUX         PERIPHS_IO_MUX_GPIO0_U

char *device_uuid = "e40bb1c3c905442ab75bf70a4f3007a0";

char sub_topic_id[SUB_TOPIC_COUNT][UUID_LENGTH] =
{
		"9053cf9491a9490f93213bc40c859c91",
		"4ec66787a5b74b46b79bcdae2b755c60",

};
char pub_topic_id[PUB_TOPIC_COUNT][UUID_LENGTH] =
{
		"a4589cc394934a9fb857a915330bc475",
		"5897f0a6b35d4bf8b7b4d8acda47f003",

};

/**
*******************************************************************************
 * @brief       wifi״̬�ı�ص�����
 * @param       [in]  wifi ����״̬
 * @return      void
 * @note        None
*******************************************************************************
*/
void ICACHE_FLASH_ATTR
wifiConnectCb(uint8_t status)
{
	if(status == STATION_GOT_IP)
	{
		mqtt_connect();
		os_printf("Already connected to WiFi\n");
	}
	else
	{
		mqtt_disconnect();
	}
}

void ICACHE_FLASH_ATTR
auto_closeDoor(void *args)
{
	CLOSE_DOOR; // ����
	os_printf("close door\n");
	mqtt_Publish(pub_topic_id[0], "0", 1, 0, 0);
}


/**
*******************************************************************************
 * @brief       GPIO�жϴ�������
 * @param       [in/out]  void
 * @return      void
 * @note        None
*******************************************************************************
*/
void pushDoor_handle(void)
{
    // ��ȡGPIO�ж�״̬
    u32 gpio_status = GPIO_REG_READ( GPIO_STATUS_ADDRESS );

    // �ر�GPIO�ж�
    ETS_GPIO_INTR_DISABLE();

    // ���GPIO�жϱ�־
    GPIO_REG_WRITE( GPIO_STATUS_W1TC_ADDRESS, gpio_status );

    // ����Ƿ��ѿ������������ж�
    if ( gpio_status & BIT( PUSH_NUM ) )
    {
        if( GPIO_INPUT_GET(PUSH_NUM) == 1 )
        {
			OPEN_DOOR; // ����
			os_printf("open door\n");

        	mqtt_Publish(pub_topic_id[0], "1", 1, 0, 0);
        }
        else
        {
        	CLOSE_DOOR;
        	os_printf("close door\n");

        	mqtt_Publish(pub_topic_id[0], "0", 1, 0, 0);
        }
    }
    // ����GPIO�ж�
    ETS_GPIO_INTR_ENABLE();
}

void ICACHE_FLASH_ATTR
mqttDataCB(uint32_t *args, const char* topic, uint32_t topic_len,
		const char *data, uint32_t data_len)
{
	int i = 0, status=0, ret = 0;

	// ����ռ����洢���������
	char *topicBuf = (char*)os_zalloc(topic_len+1),
		 *dataBuf  = (char*)os_zalloc(data_len+1);

	// �������⵽����Ŀռ���
	os_memcpy(topicBuf, topic, topic_len);
	topicBuf[topic_len] = 0;

	// �������ݵ�����Ŀռ���
	os_memcpy(dataBuf, data, data_len);
	dataBuf[data_len] = 0;
	os_printf("Receive topic: %s, data: %s \r\n", topicBuf, dataBuf);

	// ����������
	for(i=0; i<SUB_TOPIC_COUNT; i++)
	{
		ret = strncmp(topicBuf, sub_topic_id[i], topic_len);
		//os_printf("ret = %d\n", ret);
		if(!ret)
		{
			//os_printf("dataBuf:%s\n",dataBuf);
			status = atoi(dataBuf);
			status = (int)(*dataBuf - 48);
			os_printf("status:%d\n",status);
			break;
		}
	}

	switch(i)
	{
		case 0:
			if(status == 1) //open
			{
				OPEN_DOOR; // ����
				os_printf("open door\n");

				os_timer_disarm(&auto_closedoor_timer);
				os_timer_setfn(&auto_closedoor_timer, (os_timer_func_t *)auto_closeDoor, NULL);
				os_timer_arm(&auto_closedoor_timer, 3000, 0);

				mqtt_Publish(pub_topic_id[i], "1", 1, 0, 0);
				mqtt_Publish(pub_topic_id[i], "response:1", 10, 0, 0);
			}
			else if(status == 0) //close
			{
				CLOSE_DOOR; // ����
				os_printf("close door\n");
				mqtt_Publish(pub_topic_id[i], "0", 1, 0, 0);
				mqtt_Publish(pub_topic_id[i], "response:1", 10, 0, 0);
			}
			break;
		case 1:
			if(status == 1) //keep open
			{
				OPEN_DOOR; // ����
				os_printf("open door\n");
				mqtt_Publish(pub_topic_id[i], "1", 1, 0, 0);
				mqtt_Publish(pub_topic_id[i], "response:1", 10, 0, 0);
			}
			else if(status == 0) //keep close
			{
				CLOSE_DOOR; // ����
				os_printf("close door\n");
				mqtt_Publish(pub_topic_id[i], "0", 1, 0, 0);
				mqtt_Publish(pub_topic_id[i], "response:1", 10, 0, 0);
			}
			break;
		default:
			break;
	}

	os_free(topicBuf);
	os_free(dataBuf);
}
/**
*******************************************************************************
 * @brief       ���������ص�����
 * @param       [in/out]  void
 * @return      void
 * @note        None
*******************************************************************************
*/
static void key_LongPressCB( void )
{
	enter_wifiConfig();
}
/**
*******************************************************************************
 * @brief       �����̰��ص�����
 * @param       [in/out]  void
 * @return      void
 * @note        None
*******************************************************************************
*/
static void key_shortPressCB( void )
{

}

/******************************************************************************
 * FunctionName : user_rf_cal_sector_set
 * Description  : SDK just reversed 4 sectors, used for rf init data and paramters.
 *                We add this function to force users to set rf cal sector, since
 *                we don't know which sector is free in user's application.
 *                sector map for last several sectors : ABCCC
 *                A : rf cal
 *                B : rf init data
 *                C : sdk parameters
 * Parameters   : none
 * Returns      : rf cal sector
 *******************************************************************************/
uint32 ICACHE_FLASH_ATTR
user_rf_cal_sector_set(void)
{
    enum flash_size_map size_map = system_get_flash_size_map();
    uint32 rf_cal_sec = 0;

    switch (size_map) {
        case FLASH_SIZE_4M_MAP_256_256:
            rf_cal_sec = 128 - 5;
            break;

        case FLASH_SIZE_8M_MAP_512_512:
            rf_cal_sec = 256 - 5;
            break;

        case FLASH_SIZE_16M_MAP_512_512:
        case FLASH_SIZE_16M_MAP_1024_1024:
            rf_cal_sec = 512 - 5;
            break;

        case FLASH_SIZE_32M_MAP_512_512:
        case FLASH_SIZE_32M_MAP_1024_1024:
            rf_cal_sec = 1024 - 5;
            break;

        case FLASH_SIZE_64M_MAP_1024_1024:
            rf_cal_sec = 2048 - 5;
            break;
        case FLASH_SIZE_128M_MAP_1024_1024:
            rf_cal_sec = 4096 - 5;
            break;
        default:
            rf_cal_sec = 0;
            break;
    }

    return rf_cal_sec;
}
/******************************************************************************
 *
*******************************************************************************/
void ICACHE_FLASH_ATTR
user_rf_pre_init(void)
{
}


void user_init(void)
{
	//��ȡsdk�汾�Ų�ͨ�����ڴ�ӡ����
    os_printf("SDK version:%s\n", system_get_sdk_version());

	// ����wifiģʽΪstation mode
	wifi_set_opmode_current(STATION_MODE);

	Door_init(pushDoor_handle);

    {
    	// ��ʼ����������
    	single_key[0] = key_init_single( keys_Pin_NUM, keys_Pin_MUX,
        							  keys_Pin_FUNC,
									  key_LongPressCB,
									  key_shortPressCB );

    	key_param.key_num = 1;
        key_param.single_key = single_key;

        // ��ʼ����������
        key_init( &key_param );
    }

    //����mqtt
    mqtt_config(mqttDataCB);
    // ����wifi
    wifi_Connect(wifiConnectCb);
}
