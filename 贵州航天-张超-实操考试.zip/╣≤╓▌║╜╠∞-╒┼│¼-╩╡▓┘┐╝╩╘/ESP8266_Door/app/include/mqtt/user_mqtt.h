#ifndef _USER_MQTT_H_
#define _USER_MQTT_H_

#include "c_types.h"
#include "mqtt_config.h"
#include "mqtt.h"

extern MQTT_Client mqttClient;

void ICACHE_FLASH_ATTR mqtt_connect(void);
void ICACHE_FLASH_ATTR mqtt_disconnect(void);
void ICACHE_FLASH_ATTR mqtt_config(MqttDataCallback dataCb);
void ICACHE_FLASH_ATTR mqtt_Publish(const char* topic, const char* data, int data_length, int qos, int retain);

#endif

