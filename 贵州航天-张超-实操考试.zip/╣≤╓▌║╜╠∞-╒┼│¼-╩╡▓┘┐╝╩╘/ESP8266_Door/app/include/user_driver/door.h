/*
 * door.h
 *
 *  Created on: 2018��1��23��
 *      Author: Qian
 */

#include "exti.h"

#ifndef APP_INCLUDE_USER_DRIVER_DOOR_H_
#define APP_INCLUDE_USER_DRIVER_DOOR_H_

// PUSH�źŲɼ� GPIO
#define PUSH_MUX			PERIPHS_IO_MUX_GPIO4_U
#define PUSH_FUNC			FUNC_GPIO4
#define PUSH_NUM			4

// �̵��������źţ�������������
#define DOOR_MUX			PERIPHS_IO_MUX_MTDI_U
#define DOOR_FUNC			FUNC_GPIO12
#define DOOR_NUM			12

#define OPEN_DOOR			GPIO_OUTPUT_SET(DOOR_NUM, 0)
#define CLOSE_DOOR			GPIO_OUTPUT_SET(DOOR_NUM, 1)

extern void Door_init(void *GPIO_ISR_Handler);

#endif /* APP_INCLUDE_USER_DRIVER_DOOR_H_ */
