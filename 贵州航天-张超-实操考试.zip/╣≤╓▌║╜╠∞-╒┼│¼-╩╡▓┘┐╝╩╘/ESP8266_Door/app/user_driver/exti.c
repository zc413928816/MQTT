/*
 * exti.c
 *
 *  Created on: 2018��1��10��
 *      Author: Qian
 */

#include "exti.h"
#include "eagle_soc.h"
#include "ets_sys.h"
#include "osapi.h"

uint8_t        gpio_num                       = 0x00;
uint8_t        gpio_table[GPIN_INTR_NUM]      = { 0 };
intr_handle    intr_handle_map[GPIN_INTR_NUM] = { 0 };
void           *arg[GPIN_INTR_NUM]            = { 0 };


void exti_intr_handler(void* a)
{
	uint8_t i = 0;
	uint32 gpio_status = GPIO_REG_READ(GPIO_STATUS_ADDRESS);
	for(i=0; i<gpio_num; i++)
	{
		if ( gpio_status & BIT( gpio_table[i] ) )
		{
			os_printf("*****____ %d\n", i);
			if(intr_handle_map[i])
			{
				intr_handle_map[i](arg[i]);
			}
		}
	}
}


void GPIO_INTR_ATTACH(void *key_intr_handler, void *keys, uint8_t gpio_no)
{
	ETS_GPIO_INTR_ATTACH(exti_intr_handler, NULL);

	arg[gpio_num]             = keys;
	intr_handle_map[gpio_num] = (intr_handle) key_intr_handler;
	gpio_table[gpio_num++]    = gpio_no;

	os_printf("***************** %d\n",gpio_num);
	os_printf("***************** %d\n",gpio_no);
}

